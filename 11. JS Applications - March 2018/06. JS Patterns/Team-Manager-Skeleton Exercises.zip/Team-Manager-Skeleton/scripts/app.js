$(() => {
    const app = Sammy('#main', function () {
        // TODO: Define all the routes
    });

    app.run();
});