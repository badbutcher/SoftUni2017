﻿namespace SimpleMvc.Framework.Contracts
{
    public interface IRenderable
    {
        string Render();
    }
}
