﻿namespace SimpleMvc.Framework.Contracts
{
    public interface IActionResult
    {
        string Invoke();
    }
}


