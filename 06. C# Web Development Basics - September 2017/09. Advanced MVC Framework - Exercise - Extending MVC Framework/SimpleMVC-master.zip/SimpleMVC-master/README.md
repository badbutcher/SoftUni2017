# SimpleMVC
This is a Simple MVC Framework designed to mimic ASP.NET.

The framework is written for the C#-Web Course @ SoftUni and is written on .NET Core.
It uses a modified version of this WebServer : https://github.com/ivaylokenov/MyCoolWebServer 
