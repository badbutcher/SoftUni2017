﻿namespace FestivalManager.Entities.Instruments
{
    public class Microphone : Instrument
    {
	    protected override int RepairAmount => 80;
    }
}
