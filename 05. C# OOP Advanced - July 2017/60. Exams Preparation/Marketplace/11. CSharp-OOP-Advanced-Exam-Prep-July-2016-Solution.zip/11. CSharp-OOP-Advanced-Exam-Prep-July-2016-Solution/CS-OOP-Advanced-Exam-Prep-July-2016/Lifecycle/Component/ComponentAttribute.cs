﻿namespace CS_OOP_Advanced_Exam_Prep_July_2016.Lifecycle.Component
{
    using System;

    public class ComponentAttribute : Attribute
    {
    }
}
