﻿namespace CS_OOP_Advanced_Exam_Prep_July_2016.Contracts
{
    public interface IWriter
    {
        void Write(string text);
        void WriteLine(string text);
    }
}
