﻿namespace CS_OOP_Advanced_Exam_Prep_July_2016.IO.Writers
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}
