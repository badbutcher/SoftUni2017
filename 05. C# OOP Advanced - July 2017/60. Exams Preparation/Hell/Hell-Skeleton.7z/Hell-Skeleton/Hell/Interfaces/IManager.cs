﻿public interface IManager
{
}