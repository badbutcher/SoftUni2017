﻿using System;

public class Manager
{
    public string Quit(object argsList)
    {
        throw new NotImplementedException();
    }
}