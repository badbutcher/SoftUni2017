﻿using System;

public class Command
{
    public string Execute()
    {
        throw new NotImplementedException();
    }
}