﻿public class HeroCommand
{
}