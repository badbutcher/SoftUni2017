﻿public class AbstractCommand
{
    public Manager Manager { get; set; }
}