﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Manager
{
    public string Quit(object argsList)
    {
        throw new NotImplementedException();
    }
}