﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emergency_Skeleton.Core
{
    class EmergencyManagementSystem
    {

        public EmergencyManagementSystem()
        {

        }

        public string RegisterPropertyEmergency()
        {
            return null;
        }

        public string RegisterHealthEmergency()
        {
            return null;
        }

        public string RegisterOrderEmergency()
        {
            return null;
        }

        public string RegisterFireServiceCenter()
        {
            return null;
        }

        public string RegisterMedicalServiceCenter()
        {
            return null;
        }

        public string RegisterPoliceServiceCenter()
        {
            return null;
        }

        public string ProcessEmergencies()
        {
            return null;
        }

        public string EmergencyReport()
        {
            return null;
        }
    }
}
