﻿namespace _01.MassDefect_CodeFirst.Models.DTO
{
    public class AnomalyVictimsDTO
    {
        public int? Id { get; set; }

        public string Person { get; set; }
    }
}
