﻿namespace _01.MassDefect_CodeFirst.Models.DTO
{
    public class PlanetDTO
    {
        public string Name { get; set; }

        public string Sun { get; set; }

        public string SolarSystem { get; set; }
    }
}
