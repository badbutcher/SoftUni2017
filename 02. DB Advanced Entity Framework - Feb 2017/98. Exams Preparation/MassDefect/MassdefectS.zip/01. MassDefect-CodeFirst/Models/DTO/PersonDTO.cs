﻿namespace _01.MassDefect_CodeFirst.Models.DTO
{
    public class PersonDTO
    {
        public string Name { get; set; }

        public string HomePlanet { get; set; }
    }
}
