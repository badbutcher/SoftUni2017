﻿namespace _01.MassDefect_CodeFirst.Models.DTO
{
    public class AnomalyDTO
    {
        public string OriginPlanet { get; set; }

        public string TeleportPlanet { get; set; }
    }
}
