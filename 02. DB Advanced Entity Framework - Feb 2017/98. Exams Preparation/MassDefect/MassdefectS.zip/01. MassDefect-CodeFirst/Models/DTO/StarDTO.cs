﻿namespace _01.MassDefect_CodeFirst.Models.DTO
{
    public class StarDTO
    {
        public string Name { get; set; }

        public string SolarSystem { get; set; }
    }
}
