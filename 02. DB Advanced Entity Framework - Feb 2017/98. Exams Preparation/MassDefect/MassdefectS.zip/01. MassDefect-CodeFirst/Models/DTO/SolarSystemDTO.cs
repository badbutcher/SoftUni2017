﻿namespace _01.MassDefect_CodeFirst.Models.DTO
{
    public class SolarSystemDTO
    {
        public string Name { get; set; }
    }
}
