﻿namespace _01.ImportJSON.DTOs
{
    class PhotographerDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }

        public int[] Lenses { get; set; }
    }
}
