﻿namespace PhotographyWorkshop.Utilities
{
    public class Messages
    {
        public static string ErrorInvalidDataProvided = "Error. Invalid data provided";
    }
}
