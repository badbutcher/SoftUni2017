﻿namespace WeddingsPlanner.Models.Enums
{
    public enum PresentSize
    {
        NotSpecified,
        Small,
        Medium,
        Large
    }
}
