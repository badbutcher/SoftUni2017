﻿namespace WeddingsPlanner.Models.Enums
{
    public enum Gender
    {
        NotSpecified,
        Male,
        Female
    }
}