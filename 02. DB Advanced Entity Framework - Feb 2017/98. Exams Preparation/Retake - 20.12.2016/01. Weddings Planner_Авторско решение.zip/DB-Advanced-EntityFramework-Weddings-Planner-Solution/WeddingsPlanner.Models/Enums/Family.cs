﻿namespace WeddingsPlanner.Models.Enums
{
    public enum Family
    {
        Bride,
        Bridegroom
    }
}
