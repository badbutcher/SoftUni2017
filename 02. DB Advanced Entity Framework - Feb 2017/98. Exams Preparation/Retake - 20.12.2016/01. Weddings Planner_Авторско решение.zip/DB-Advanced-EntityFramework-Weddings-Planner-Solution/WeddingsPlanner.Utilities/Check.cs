﻿namespace WeddingsPlanner.Utilities
{
    public class Check
    {
    }
}
