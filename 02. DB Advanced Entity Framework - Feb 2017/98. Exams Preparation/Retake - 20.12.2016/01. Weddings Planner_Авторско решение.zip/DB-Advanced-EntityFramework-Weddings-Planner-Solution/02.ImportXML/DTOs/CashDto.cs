﻿namespace _02.ImportXML.DTOs
{
    class CashDto
    {
        public string Type { get; set; }
        public int WeddingId { get; set; }
        public string GuestName { get; set; }
        public decimal Amount { get; set; }

    }
}
