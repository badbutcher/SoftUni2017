function startApp() {

}