﻿namespace VegetableNinja.Interfaces
{
    public interface IOutputWriter
    {
        void WriteLine(string output);

        void Write(string output);
    }
}
