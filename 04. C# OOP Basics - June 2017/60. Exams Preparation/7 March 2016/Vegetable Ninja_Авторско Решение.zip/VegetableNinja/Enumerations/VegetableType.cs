﻿namespace VegetableNinja.Enumerations
{
    public enum VegetableType
    {
        Asparagus,
        Blank,
        Broccoli,
        CherryBerry,
        Mushroom,
        Royal,
        MeloLemonMelon
    }
}
