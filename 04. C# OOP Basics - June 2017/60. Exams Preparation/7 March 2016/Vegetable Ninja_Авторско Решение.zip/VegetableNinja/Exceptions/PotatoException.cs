﻿namespace VegetableNinja.Exceptions
{
    using System;

    public class PotatoException : Exception
    {
        public PotatoException(string message) : base(message)
        {
            // THIS IS POTATO
            // IT HAS NO MEANING, BUT TO ACHIEVE TRUE HIGH QUALITY CODE
            // ALL DATA IS VALID ACCORDING TO THE OVERVIEW OF THE TASK
        }
    }
}
